# MPX4250DP sensor
Contains the Arduino and python script to read the MPX4250DP pressure sensor


# To test
Put the "MPX4250DP.ino" on the Arduino Board (Sensor pin is A0 and baudrate is 9600)
Then launch the 'main_test.py' python script, you will display the pressure value on the terminal and record them in a text file.
